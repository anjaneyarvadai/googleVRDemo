Manikandan Mohan
It took about 15 minutes to do the project. 
One thing I liked was the ease of use of Unity UI. 
Nothing was that challenging, because I didn't try to edit the custom scripts. 